# Single Exam Paper Analysis Template
## Complete 11-Module Framework

This reference provides the complete, detailed template for analyzing a single exam paper. All 11 modules must be completed in strict order for each exam paper.

---

## Module 1: Basic Attribute Identification

### Required Dimensions:
1. **Subject & Educational Level Identification**
   - Automatically and precisely determine the corresponding subject and applicable educational level
   - Predict exam type (Quiz / Chapter Test / Midterm Exam / Final Exam / Graduate Entrance Exam / Certification Exam, etc.)

2. **Full Score & Duration Estimation**
   - Extract the full score value of the exam paper
   - Estimate the standard exam duration based on question types and quantity

3. **Question Type Distribution Table**
   - Present in table format with columns: Question Type, Quantity, Score per Question, Total Score, Score Percentage, Core Assessment Function

4. **Overall Structure Characteristics**
   - Note whether the paper is divided into Volume I / Volume II
   - Note whether there are compulsory vs. optional sections
   - Note whether there are additional/bonus questions
   - Describe any other structural features

5. **Textbook Manifest (for multi-textbook papers)**
   - If the paper covers multiple textbooks, output a Textbook Manifest table listing every identified textbook with its abbreviation and full identifier.
   - Format:
     | # | 教材简称 | 教材全称 | 识别方式 |
     |---|---------|---------|---------|
     | 1 | 必修一 | 人教版《数学》必修第一册 | 用户指定 / 自动匹配 |
     | 2 | 必修二 | 人教版《数学》必修第二册 | 用户指定 / 自动匹配 |
     | 3 | 选必一 | 人教版《数学》选择性必修第一册 | 用户指定 / 自动匹配 |
   - For single-textbook papers, this table is optional but recommended to clarify which textbook is used.

### Example Table Format:
| Question Type | Quantity | Score per Question | Total Score | Score Percentage | Core Assessment Function |
|---------------|----------|-------------------|-------------|------------------|--------------------------|
| Multiple Choice | - | - | - | - | Knowledge breadth, concept discrimination |
| Fill in the Blank | - | - | - | - | Basic knowledge mastery, calculation accuracy |
| Short Answer | - | - | - | - | Knowledge application, expression ability |
| Comprehensive Problem | - | - | - | - | Integrated application, logical reasoning |

---

## Module 2: Knowledge Point System Deconstruction (with Textbook Catalog Anchoring)

### Required Dimensions:
1. **Textbook Manifest (教材清单)** — if not already shown in Module 1
   - List every textbook identified for this paper with abbreviation and full name
   - Use abbreviations consistently in all subsequent per-question tables

2. **Four-Level Annotation Method** (教材 → 章 → 节 → 具体知识点)
   - Level 0: Source textbook (来源教材) — textbook abbreviation
   - Level 1: Major knowledge modules (知识模块)
   - Level 2: Chapter / Section (章 / 节)
   - Level 3: Specific exam points / knowledge points (具体知识点)
   - Apply per-question correspondence for all examined knowledge points
   - Naming must be consistent with each textbook's official catalog terminology
   - Ensure uniform granularity across all questions
   - **Each knowledge point MUST be anchored to exactly one source textbook**

3. **Textbook Anchoring (Multi-Textbook Hybrid Priority)**
   - **Priority 1**: If user specified textbook(s), use each one for its corresponding knowledge domain
   - **Priority 2**: If not specified, auto-match the full set of mainstream national textbooks that the paper's scope covers
   - **Priority 3**: If neither is available, use general subject knowledge structure with provisional marking per knowledge domain
   - Map each question's exam points to specific chapters and sections of the correct source textbook
   - Clearly indicate the source textbook for every knowledge point
   - **Anchoring format**: **[教材简称] 章 → 节 → 具体知识点**
   - Each textbook's chapter numbering is independent — do not merge across textbooks

3. **Knowledge Module Distribution Statistics**
   - Statistic the question quantity, score value, and percentage for each Level 1 module
   - Present in score distribution table format

4. **Knowledge Point Classification**
   - **High-frequency core exam points**: High score value, high frequency of examination
   - **Ordinary exam points**: Standard coverage, moderate frequency
   - **Marginal exam points**: Low score value, low frequency of examination

5. **Knowledge Point Coverage Estimation**
   - Estimate the percentage of knowledge points covered by the exam paper, based on the determined textbook's full scope
   - Identify core chapters/sections not covered by this exam

### Per-Question Knowledge Point Mapping Format:
| Question Number | 来源教材 | Level 1 知识模块 | Level 2 章/节 | Level 3 具体知识点 | 对标教材章·节 | Score |
|-----------------|---------|-----------------|----------------|---------------------|--------------|-------|
| Q1 | 必修一 | - | - | - | - | - |
| Q2 | 必修二 | - | - | - | - | - |

---

## Module 3: Exam Specification Reverse Engineering

### Required Dimensions:
1. **Exam Scope Restoration**
   - Restore the exam scope corresponding to this paper
   - Clearly identify core assessment content, general assessment content, and non-key content

2. **Competency Level Classification**
   - Determine the exam specification competency level corresponding to each knowledge point
   - Levels: Understanding / Comprehension / Mastery / Comprehensive Application
   - Based on question types, questioning methods, and solution depth

3. **Academic Quality Level Alignment**
   - Corresponding to course requirements and learning objectives
   - Clearly identify the competency level corresponding to each knowledge point

4. **Core Assessment Focus Summary**
   - Summarize the core assessment focus of the exam
   - Clarify the competency orientation and proposition principles for this course exam

---

## Module 4: Difficulty Quantitative Assessment

### Required Dimensions:
1. **Per-Question Difficulty Labeling**
   - Label each question with a difficulty level
   - Unified classification standards:
     - **Simple questions**: Single knowledge point, direct application of concepts/formulas, no traps, equivalent to textbook basic example difficulty
     - **Medium questions**: 2-3 related knowledge points, require 1-2 steps of reasoning/transformation, contain common error-prone points
     - **Difficult questions**: Cross-module multi-knowledge-point integration, require multi-step derivation / context transformation / model construction, novel questioning, high openness

2. **Difficulty Distribution Statistics**
   - Statistic the score percentage and question quantity percentage for simple, medium, and difficult questions
   - Present in table format

3. **Overall Difficulty Coefficient Calculation**
   - Formula:
     ```
     Estimated difficulty coefficient = (Simple score × 0.85 + Medium score × 0.6 + Difficult score × 0.3) ÷ Total score
     ```
   - Scoring rate benchmarks: Simple questions 0.85, Medium questions 0.6, Difficult questions 0.3

4. **Difficulty Gradient Design Analysis**
   - Describe the difficulty arrangement pattern (e.g., whether from easy to difficult)
   - Identify the position of final challenging (压轴) questions
   - Analyze difficulty differences across knowledge modules

5. **Discrimination Power Assessment**
   - Evaluate the paper's ability to stratify and select students of different levels
   - Determine whether the paper has good discrimination power

### Difficulty Distribution Table Format:
| Difficulty Level | Question Quantity | Quantity Percentage | Total Score | Score Percentage |
|------------------|-------------------|---------------------|-------------|------------------|
| Simple | - | - | - | - |
| Medium | - | - | - | - |
| Difficult | - | - | - | - |

---

## Module 5: Subject Core Competencies & Capability Dimension Analysis

### Required Dimensions:
1. **Core Competency Labeling (新课标核心素养)**
   - Corresponding to the subject's New Curriculum Standard (新课标) core competencies
   - **K-12 subjects**: Must use the official 新课标 core competency framework for each subject:
     - 语文: 语言建构与运用、思维发展与提升、审美鉴赏与创造、文化传承与理解
     - 数学: 数学抽象、逻辑推理、数学建模、直观想象、数学运算、数据分析
     - 英语: 语言能力、文化意识、思维品质、学习能力
     - 物理: 物理观念、科学思维、科学探究、科学态度与责任
     - 化学: 宏观辨识与微观探析、变化观念与平衡思想、证据推理与模型认知、科学探究与创新意识、科学态度与社会责任
     - 生物: 生命观念、科学思维、科学探究、社会责任
     - 历史: 唯物史观、时空观念、史料实证、历史解释、家国情怀
     - 地理: 人地协调观、综合思维、区域认知、地理实践力
     - 政治/道德与法治: 政治认同、科学精神、法治意识、公共参与
   - **Higher education**: Use the corresponding discipline-specific competency framework
   - Label each question with the type(s) of core competency it primarily assesses

2. **Core Competency Score Distribution**
   - Statistic the score percentage of each type of core competency
   - Present in table format
   - Clarify the competency assessment focus and bias of this exam paper

3. **General Competency Assessment**
   - Extract the core general competencies assessed across the paper:
     - Knowledge memorization and recall (识记背诵)
     - Concept discrimination (概念辨析)
     - Logical reasoning (逻辑推理)
     - Calculation and solution (运算求解)
     - Information extraction (信息提取)
     - Comprehensive application (综合应用)
     - Inquiry and innovation (探究创新)
     - Written expression (文字表达)
     - Other subject-specific competencies

---

## Module 6: Question Context & Material Feature Analysis

### Required Dimensions:
1. **Contextualized Question Statistics**
   - Categorize and statistic the proportion of contextualized questions
   - Categories:
     - 生活实践情境 (Real-life practice context)
     - 学习探索情境 (Learning exploration context)
     - 社会热点情境 (Social hotspot context): current events, policy changes, social phenomena
     - 学术前沿情境 (Academic/research frontier context)
     - 传统文化情境 (Traditional cultural context)
     - 无情境纯知识题 (No context / pure knowledge questions)
   - Present in table format with score and percentage for each category

2. **Material Source Characteristics**
   - Analyze whether the materials combine engineering applications
   - Analyze whether materials draw from real-life phenomena
   - Analyze whether materials incorporate scientific and technological progress
   - Analyze whether materials include historical or classic examples
   - Other material source characteristics

3. **Contextual Proposition Patterns**
   - Summarize common methods of contextualized proposition
   - Analyze the assessment purposes of contextualization

---

## Module 7: Proposition Characteristics & Trap Setting Analysis

### Required Dimensions:
1. **Overall Proposition Style**
   - Summarize the overall proposition style of this paper
   - Categories: Foundation-oriented / Competency-oriented / Innovation-oriented / Application-oriented, etc.

2. **High-Frequency Proposition Traps**
   - Extract high-frequency proposition traps and error-prone point setting methods:
     - Concept confusion
     - Hidden conditions
     - Calculation traps
     - Question reading misconceptions
     - Fixed mindset / thinking定式
     - Other subject-specific trap types

3. **Question Type Innovation Degree**
   - Statistic the proportion of conventional questions, variant questions, and innovative question types
   - Describe the characteristics of innovative question types

---

## Module 8: Score Loss Risk Prediction

### Required Dimensions:
1. **Module-Based High-Frequency Score Loss Points**
   - Organize high-frequency score loss points by knowledge module
   - Label corresponding question numbers

2. **Score Loss Type Classification**
   - **Knowledge-based score loss**: Insufficient knowledge mastery
   - **Method-based score loss**: Lack of problem-solving methods
   - **Question-reading score loss**: Misreading or misunderstanding questions
   - **Calculation-based score loss**: Calculation errors
   - **Standardization-based score loss**: Non-standard expression or formatting

3. **Overall Score Loss Estimation**
   - Estimate the average score loss range for the entire paper
   - Identify high-score bottleneck points

---

## Module 9: Single Paper Preparation Priority & Review Suggestions

### Required Dimensions:
1. **Knowledge Point Review Priority Classification**
   - Based on score proportion and assessment depth
   - Categories:
     - **Core must-master**: Highest priority, highest score weight
     - **Key consolidation**: Important but secondary priority
     - **Basic understanding**: Foundational knowledge, lower priority

2. **Targeted Review Strategies**
   - Based on the proposition characteristics of this paper
   - Provide targeted review strategies and score improvement directions

3. **Error-Prone Point Avoidance Suggestions**
   - Based on error-prone points and score loss risks
   - Provide specific avoidance suggestions

---

## Module 10: Analysis Notes

### Required Content:
1. **Limitations Statement**
   - Clearly state: This conclusion is a reverse derivation result based on a single exam paper
   - Note that there are limitations in knowledge point coverage
   - Emphasize that complete exam specifications and proposition patterns require cross-validation with multiple sets of similar exam papers

2. **Benchmark Basis**
   - Explain the benchmark basis for this analysis
   - Include: corresponding course requirements, determined textbook content, general proposition specifications

3. **Textbook Version(s)**
   - If single textbook: state the textbook used for anchoring (author + title + edition)
   - If multiple textbooks: use a table listing each textbook's full identifier and anchoring status
   - If auto-matched: note "自动匹配: [出版社]《[教材名称]》[第X版]"
   - If user-specified: note "用户指定: [作者]《[书名]》[第X版]"
   - If provisionally anchored: note "临时性锚定（通用学科知识结构），建议提供具体教材以获得精确章节级对齐"
   - **Multi-textbook format**:
     | # | 教材简称 | 教材全称 | 来源 | 锚定方式 |
     |---|---------|---------|------|---------|
     | 1 | 必修一 | 人教版《数学》必修第一册 | 自动匹配 | 精确锚定 |
     | 2 | 必修二 | 人教版《数学》必修第二册 | 自动匹配 | 精确锚定 |
     | 3 | 选必一 | 人教版《数学》选择性必修第一册 | 自动匹配 | 精确锚定 |

---

## Module 11: Self-Inspection & Review Report (Iterative Loop)

### Iteration Tracking Table
After completing all 10 analysis modules, enter the iterative inspection loop. For each iteration, record:

| Iteration | Defects Found | Defects Fixed | Status |
|-----------|--------------|---------------|--------|
| 1 | [N] | [N] | → Iteration 2 |
| 2 | [N] | [N] | → Iteration 3 |
| ... | ... | ... | ... |
| N | 0 | — | PASS |

### Per-Iteration Inspection Checklist (apply to every iteration, no dimension exempt)
For each iteration, run the FULL checklist below. Do not skip any dimension.

1. **Module Completeness Check**
   - Verify whether all 11 mandatory analysis modules for this exam paper are fully covered
   - Verify whether module order and titles fully meet requirements
   - State whether there are any omissions or order errors

2. **Subject & Textbook Anchoring Check**
   - Review whether subject identification, educational level determination, and textbook matching are accurate
   - **Multi-textbook completeness**: Verify every textbook in the Textbook Manifest is actually used — no unused listed textbook and no unlisted textbook silently referenced
   - **Textbook authenticity verification (CRITICAL)**: Verify every chapter number, section name, and knowledge point hierarchy against each textbook's actual official table of contents. Mark any fabricated chapter/section that does not exist in any textbook. If fabrication is found, correct it to the actual TOC entry. If a textbook's actual TOC is unavailable, mark all anchoring to that textbook as provisional. The rule: what's not in the actual textbook must be flagged as error or provisional — never output fabricated chapter structures as if they were real.
   - **Cross-textbook boundary check**: Verify no knowledge point is anchored to the wrong textbook (e.g., a 必修第二册 knowledge point incorrectly attributed to 必修第一册)
   - Verify whether all exam point anchoring textbook chapters are consistent with the determined textbook(s)
   - State whether there are any deviations

3. **Knowledge Point & Difficulty Check**
   - Review whether the three-level knowledge point classification (章 → 节 → 具体知识点) has uniform granularity
   - Verify whether difficulty assessment strictly follows unified standards
   - Check whether there is any subjective overestimation or underestimation of difficulty

4. **Data Calculation Accuracy Check**
   - Review calculation accuracy of question type score percentages, module score percentages, difficulty coefficient, and various statistical data
   - State whether there are any calculation errors

5. **Conclusion Basis Check**
   - Review whether all conclusions are supported by corresponding exam paper questions
   - Check for any unsupported subjective assumptions
   - State whether there are any inferences detached from the exam paper

6. **Core Competency & Context Assignment Check**
   - Verify each competency dimension assignment is justified by the paper content
   - Verify each context category is correctly identified per new curriculum standards
   - Check for missing or misclassified entries

7. **Proposition Characteristic & Trap Depth Check**
   - Review whether proposition pattern descriptions are substantive, not generic
   - Verify trap identification is specific to actual questions, not templated
   - Check whether trap categories match the paper's actual difficulty profile

8. **Preparation Strategy Executability Check**
   - Verify review priorities have explicit chapter-level grounding
   - Check whether specific actions are actionable (knowing what to do + how to do it)
   - Confirm strategy addresses every high-risk point identified in Module 8

9. **Cross-Module Logical Consistency Check**
   - Verify Module 2 (knowledge points) ↔ Module 4 (difficulty) alignment
   - Verify Module 5 (competencies) ↔ Module 6 (context) ↔ Module 7 (propositions) coherence
   - Verify Module 8 (risk prediction) ↔ Module 9 (priority) correlation
   - Check for any internal contradictions across modules

### Iteration N — Findings & Fixes
For each iteration, record:
- **Defect #[X]**: [Description of defect, affected module, severity]
- **Fix**: [What was corrected and where]

### Iteration N — Re-inspection Result
- **Total defects found**: [0 or number]
- **Verdict**: PASS (0 defects) / FAIL (defects remain, proceed to Iteration N+1)

### Final Verdict (after last iteration)
```
Iteration [N]: PASS — 0 defects. All 11 modules verified complete and accurate.
Textbook anchoring: [verified against actual TOC / provisional].
Cross-module consistency: CONFIRMED.
Ready for output / Step 3 cross-paper analysis.
```

---

## Important Reminders
- All 11 modules must be completed for each exam paper
- Module order must be strictly followed, no skipping or merging
- All conclusions must have exam paper evidence
- Question numbers must be included in all question-related judgments
- Knowledge point naming must be consistent with each textbook's official catalog terminology
- Knowledge point anchoring format is always: **[教材简称] 章 → 节 → 具体知识点**
- Textbook anchoring follows multi-textbook hybrid priority: user-specified → auto-match full set → general fallback
- Every knowledge point must have a valid source textbook; per-question tables must include "来源教材" column
- Difficulty standards must be uniformly applied across all questions
- For K-12 papers, use 新课标 core competency frameworks; for higher education, use discipline-specific frameworks
- Context categories must include 社会热点情境 and 传统文化情境 in addition to the standard categories
- **No fabrication, no deviation**: All textbook chapter structures, knowledge point catalogs, and subject frameworks used in analysis must come from the references/ files or the actual textbook's official table of contents. Never fabricate, guess, or use your own knowledge to fill in chapter/section structures. References contain what you may use; anything not in them must not be invented. If unavailable, mark as provisional.
- **Iterative inspection mandatory**: After completing Module 11, you MUST enter the CHECK → FIX → RECHECK loop. Every fix triggers a full re-inspection from scratch. The loop does not end until an iteration yields zero defects. Never output with known defects — if you see it, fix it, then check again.
- **Output format**: The final report must be generated as a physical file (Word .docx by default, or PDF if user specifies). Default save path is `D:\下载\`. Ask user to confirm save path before generating. See SKILL.md Output Format Requirements for full details.
- **Table of Contents**: The generated Word document MUST include a Table of Contents (目录). Place the TOC on its own page immediately after the cover page and before the analysis content begins. The TOC page heading should be "目录" formatted as Heading 1. Insert a TOC field via python-docx XML manipulation, followed by the note "(请在 Word 中右键点击此处 → 更新域，以生成完整目录)".
