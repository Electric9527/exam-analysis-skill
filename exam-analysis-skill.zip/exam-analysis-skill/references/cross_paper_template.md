# Cross-Paper Comprehensive Analysis & Overall Review Guidance
## Complete 5-Module Framework

This reference provides the complete template for cross-paper comprehensive analysis. This analysis is conducted ONLY after all single-paper analyses are fully completed.

---

## Module 12: Cross-Paper Knowledge Point Frequency & Weight Summary

### Required Dimensions:
1. **Level 1 Module Score Weight Summary**
   - Unified statistics of cumulative scores and average percentage for each Level 1 knowledge module across all exam papers
   - Present in cross-paper module score weight table format

2. **Level 3 Exam Point Frequency Ranking**
   - Sort Level 3 exam points by dual dimensions: "frequency of appearance + cumulative score"
   - **Include source textbook** for each high-frequency point
   - Classify into three categories:
     - **High-frequency must-know points**: Appear in every exam / high cumulative score percentage
     - **Medium-frequency regular points**: Appear in more than half of the exam papers
     - **Low-frequency marginal points**: Appear rarely, low score weight

3. **Textbook Alignment of Core High-Frequency Points**
   - For each core high-frequency point, label the specific source textbook, volume, chapter, and section
   - Use consistent textbook abbreviations across all papers in the set
   - Clarify the core textbook scope for review
   - **For multi-textbook papers**: Summarize which textbooks carry the most exam weight across all papers

### Cross-Paper Module Score Weight Table Format:
| Level 1 Knowledge Module | Paper 1 Score | Paper 2 Score | Paper 3 Score | ... | Cumulative Score | Average Percentage |
|-------------------------|---------------|---------------|---------------|-----|------------------|--------------------|
| Module A | - | - | - | - | - | - |
| Module B | - | - | - | - | - | - |

---

## Module 13: Cross-Paper Proposition Patterns & Difficulty Overview

### Required Dimensions:
1. **Overall Difficulty Range Summary**
   - Summarize the overall difficulty range across multiple exam papers
   - Analyze difficulty stability, fluctuation range, and fluctuating modules
   - Identify which knowledge modules show consistent difficulty and which vary

2. **Common Proposition Patterns**
   - Extract common proposition styles across all exam papers
   - Identify shared competency assessment focuses
   - Summarize common trap setting methods
   - Identify universal question-solving patterns

3. **Question Type Structure Analysis**
   - Summarize stable components of the question type structure
   - Identify innovative change trends
   - Clarify compulsory question types, optional question types, and new question types
   - Analyze the evolution direction of question type innovation

---

## Module 14: Overall Review Direction

### Required Dimensions:
1. **Core Strategy Orientation**
   - Clarify the core strategy orientation for exam preparation
   - Strategy types:
     - Foundation consolidation orientation
     - Competency advancement orientation
     - Comprehensive breakthrough orientation
     - Exam technique orientation
     - Mixed/combined orientation

2. **Core Review Principles**
   - State the core principles of review
   - Provide priority ranking for review content
   - Identify common pitfalls to avoid during review

3. **Time Allocation Guidance**
   - Clarify the core modules where time should be allocated more
   - Identify key competency training priorities
   - Provide suggested time allocation ratios

---

## Module 15: Core Review Priorities

### Required Dimensions:
1. **Core Exam Points by Module Priority**
   - List core exam points that must be mastered with priority
   - Include corresponding textbook chapters and sections
   - Specify examination forms for each core point
   - Organize by knowledge module priority

2. **Core Question Types & Solution Methods**
   - Identify core question types that must be mastered proficiently
   - List corresponding solution methods and approaches
   - Specify competency requirements for each question type

3. **High-Frequency Error-Prone Points**
   - Organize high-frequency error-prone points, easily confused points, and score loss disaster areas
   - List them as key breakthrough content
   - Include specific avoidance strategies

---

## Module 16: Phased Specific Review Content Plan

### Required Dimensions:
1. **Foundation Consolidation Phase**
   - Clarify textbook chapters and knowledge point scope to cover
   - Specify training content and methods
   - Define attainment requirements and completion standards
   - Suggested duration and time allocation

2. **Strengthening & Enhancement Phase**
   - Identify key modules to break through
   - Specify key question types and methods to master
   - Provide supporting training methods
   - Define attainment requirements and progress benchmarks

3. **Sprint & Review Phase**
   - Clarify review focus points
   - Specify full-paper training methods and frequency
   - Identify gap-filling directions
   - Provide exam standardization and technique guidance
   - Define final sprint goals and mental preparation

---

## Important Rules for Cross-Paper Analysis
1. **Complete single-paper analysis first**: All single-paper analyses must be fully completed before starting cross-paper analysis
2. **Unified system**: Use unified knowledge point naming system, difficulty assessment standards, and consistent textbook abbreviations across all exam papers. For multi-textbook papers, maintain the same textbook manifest and abbreviations throughout.
3. **Consistent caliber**: Ensure cross-paper analysis measurement standards are completely consistent
4. **Independent single-paper analysis**: Each exam paper analysis must be independent and complete, do not use cross-paper summary to replace single-paper complete analysis
5. **Clear labeling**: Each analysis must clearly label the exam paper serial number / name, presented as independent sections
6. **No premature summarization**: Do not summarize in advance, do not mix analyses, do not replace single-paper analysis with summaries
7. **Output format**: The final cross-paper report must be generated as a physical file (Word .docx by default, or PDF if user specifies). Default save path is `D:\下载\`. Ask user to confirm save path before generating. See SKILL.md Output Format Requirements for full details.
8. **Table of Contents**: The generated Word document MUST include a Table of Contents (目录). Place the TOC on its own page immediately after the cover page and before the analysis content begins. The TOC page heading should be "目录" formatted as Heading 1. Insert a TOC field via python-docx XML manipulation, followed by the note "(请在 Word 中右键点击此处 → 更新域，以生成完整目录)".
