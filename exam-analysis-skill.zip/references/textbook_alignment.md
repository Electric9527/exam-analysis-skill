# Textbook Alignment Guide
## Hybrid Textbook Anchoring: User-Specified → Auto-Match → General Fallback

This reference provides guidance for the **hybrid textbook anchoring strategy**. The system follows a strict priority chain: (1) user-specified textbook → (2) auto-match mainstream textbook → (3) general subject knowledge structure with provisional marking.

---

## Core Principle: Hybrid Anchoring Priority Chain

```
Priority 1:  User-specified textbook (Author + Title + Edition)
    ↓ (if not specified)
Priority 1.5:  Proactively ask user to provide textbook → wait for response
    ↓ (if user opts for auto-match or doesn't provide)
Priority 2:  Auto-identify subject → auto-match mainstream textbook
    ↓ (if cannot determine)
Priority 3:  General subject knowledge structure + provisional marking
```

**Mandatory rule**: Follow this priority chain strictly. Never skip a priority level. All knowledge point naming must match the determined textbook catalog system. The anchoring format is always: **章 → 节 → 具体知识点**.

---

## Priority 1: User-Specified Textbook

### Input Format
Users may specify a textbook using the following format:
- **Author + Book Title + Edition**
- Example: 邱关源《电路》第六版
- Example: 同济大学数学系《高等数学》第七版
- Example: 人教版《数学》八年级下册
- Example: 严蔚敏《数据结构》C语言版

### Processing Rules
When a user specifies a textbook:
1. Use it as the exclusive anchoring system for all knowledge points
2. Anchor every exam point to the textbook's specific 章 and 节
3. All knowledge point naming must match that textbook's official catalog terminology
4. Note the textbook version in Module 10 (Analysis Notes)
5. Skip the auto-matching step entirely — do not override the user's choice

---

## Priority 1.5: Interactive Textbook Prompt (User-Specified Override)

When no textbook is specified by the user, the system MUST proactively ask before falling back to auto-matching.

### Prompt Procedure
1. Identify the subject area, educational stage, and exam type from the paper content
2. Display the identified information to the user:
   ```
   已识别：学科=[subject]，学段=[stage]，考试类型=[exam type]
   请提供本次考试使用的教材（作者+书名+版次），例如：邱关源《电路》第六版、人教版《数学》八年级下册。
   如不确定教材版本，可回复"自动匹配"，我将使用主流教材进行锚定。
   ```
3. Wait for user response — do not proceed to auto-matching until the user replies
4. If user provides a specific textbook, treat it as Priority 1 and use it
5. If user replies "自动匹配" or equivalent, proceed to Priority 2 auto-matching

---

## Priority 2: Automatic Subject Identification & Mainstream Textbook Matching

When no textbook is specified by the user, autonomously identify the subject and match the mainstream textbook.

### Automatic Subject Identification Process
1. Read the exam paper content thoroughly
2. Identify key subject indicators:
   - Terminology and vocabulary specific to the subject
   - Question types characteristic of the subject
   - Knowledge domain and concepts
   - Symbols, formulas, or notation systems
3. Determine the educational stage and level
4. Auto-match the corresponding mainstream textbook

### K-12 Subject Indicators (中小学)

| Subject (学科) | Key Indicators |
|----------------|----------------|
| **语文 (Chinese)** | 阅读理解、古诗文默写、文言文翻译、作文/写作、现代文阅读、语言文字运用、名著阅读 |
| **数学 (Mathematics)** | 代数、几何、函数、概率统计、三角函数、数列、立体几何、解析几何、导数、向量 |
| **英语 (English)** | 阅读理解/Reading Comprehension、完形填空/Cloze、语法填空/Grammar、书面表达/Writing、听力/Listening |
| **物理 (Physics)** | 力学、电学、光学、热学、电磁学、运动学、牛顿定律、电路分析、能量守恒 |
| **化学 (Chemistry)** | 元素周期表、化学反应、化学方程式、有机化学、无机化学、电化学、化学平衡 |
| **生物 (Biology)** | 细胞、遗传、进化、生态、光合作用、呼吸作用、基因、DNA、种群 |
| **历史 (History)** | 中国古代史、中国近现代史、世界史、朝代、事件、人物、制度、经济、文化 |
| **地理 (Geography)** | 自然地理、人文地理、区域地理、气候、地形、人口、城市、农业、工业 |
| **政治/道德与法治 (Politics/Morality & Law)** | 经济生活、政治生活、文化生活、哲学、法律常识、国情、时政 |

### Higher Education Subject Indicators

| Subject Category | Key Indicators |
|-----------------|----------------|
| **电气工程 (Electrical Engineering)** | 电路 (circuits), 信号与系统 (signals & systems), 电磁场 (electromagnetics), 模拟电子技术 (analog electronics), 数字电子技术 (digital electronics), 电力系统 (power systems), KVL/KCL, 相量法 (phasors), 传递函数 (transfer functions), 频率响应 (frequency response) |
| **数学 (Mathematics)** | 高等数学 (calculus/advanced math), 线性代数 (linear algebra), 概率论与数理统计 (probability & statistics), 微分方程 (differential equations), 数值分析 (numerical methods), 实变函数 (real analysis), 复变函数 (complex analysis) |
| **物理 (Physics)** | 力学 (mechanics), 电磁学 (electromagnetism), 光学 (optics), 热力学 (thermodynamics), 量子物理 (quantum physics), 固体物理 (solid state physics) |
| **计算机科学 (Computer Science)** | 算法 (algorithms), 数据结构 (data structures), 程序设计 (programming), 操作系统 (operating systems), 数据库 (databases), 计算机网络 (networks), 编译原理 (compilers) |
| **化学 (Chemistry)** | 有机化学 (organic chemistry), 物理化学 (physical chemistry), 分析化学 (analytical chemistry), 无机化学 (inorganic chemistry), 生物化学 (biochemistry) |
| **生物 (Biology)** | 分子生物学 (molecular biology), 细胞生物学 (cell biology), 遗传学 (genetics), 生态学 (ecology), 生理学 (physiology), 微生物学 (microbiology) |
| **经济学 (Economics)** | 微观经济学 (microeconomics), 宏观经济学 (macroeconomics), 计量经济学 (econometrics), 金融学 (finance), 国际贸易 (international trade) |
| **力学 (Mechanics)** | 理论力学 (theoretical mechanics), 材料力学 (material mechanics), 流体力学 (fluid mechanics), 结构力学 (structural mechanics), 弹性力学 (elastic mechanics) |

### Educational Stage Determination

**K-12 Education Stages (中小学)**

| Stage | Grade Range | Characteristics |
|-------|-------------|-----------------|
| **小学 (Primary)** | Grades 1-6 | Basic knowledge, simple concepts, foundational skills |
| **初中 (Junior High)** | Grades 7-9 | Systematic subject knowledge, moderate difficulty, 中考 preparation |
| **高中 (Senior High)** | Grades 10-12 | Deep theoretical knowledge, high difficulty, 高考 preparation |

**Higher Education Stages**

| Stage | Characteristics |
|-------|-----------------|
| **本科 (Undergraduate)** | Systematic professional knowledge, theoretical depth and mathematical rigor, application-oriented problem solving |
| **研究生 (Graduate)** | Advanced specialized knowledge, research-oriented content, cutting-edge topics included |
| **高职 (Vocational/Technical)** | Practical skills focus, application-oriented, less theoretical depth |

### Determination Factors
- Complexity and depth of knowledge points
- Mathematical/computational requirements
- Depth of theoretical reasoning
- Question type complexity
- Overall difficulty level relative to educational stage curriculum standards

---

## K-12 Mainstream Textbook Auto-Matching

### Textbook Priority Rules for K-12
1. **语文 (Chinese)**: 部编版 (MoE-compiled) — mandatory national standard
2. **历史 (History)**: 部编版 (MoE-compiled) — mandatory national standard
3. **道德与法治/政治 (Politics)**: 部编版 (MoE-compiled) — mandatory national standard
4. **数学 (Mathematics)**: 人教版 (PEP) — most widely used national standard
5. **英语 (English)**: 人教版 (PEP) — most widely used national standard
6. **物理 (Physics)**: 人教版 (PEP) — most widely used national standard
7. **化学 (Chemistry)**: 人教版 (PEP) — most widely used national standard
8. **生物 (Biology)**: 人教版 (PEP) — most widely used national standard
9. **地理 (Geography)**: 人教版 (PEP) — most widely used national standard

### Textbook Naming Convention for Output
```
[学科] [学段] - [出版社]《[教材名称]》[册次]
```

Examples:
- 语文 初中 - 部编版《语文》八年级上册
- 数学 高中 - 人教版《数学》必修第一册
- 物理 初中 - 人教版《物理》八年级下册

---

## Higher Education Mainstream Textbook Auto-Matching

### Nationally Recognized Standard Textbooks

| Subject | Standard Textbook |
|---------|-------------------|
| 高等数学 (Advanced Math) | 同济大学数学系《高等数学》第七版 |
| 线性代数 (Linear Algebra) | 同济大学数学系《线性代数》第六版 |
| 概率论与数理统计 | 浙江大学 盛骤《概率论与数理统计》第四版 |
| 大学物理 (College Physics) | 马文蔚《物理学》第六版 / 程守洙《普通物理学》第七版 |
| 电路 (Circuit Theory) | 邱关源《电路》第六版 |
| 信号与系统 | 郑君里《信号与系统》第三版 |
| 模拟电子技术 | 童诗白《模拟电子技术基础》第五版 |
| 数字电子技术 | 阎石《数字电子技术基础》第六版 |
| C程序设计 | 谭浩强《C程序设计》第五版 |
| 数据结构 | 严蔚敏《数据结构》C语言版 |
| 计算机网络 | 谢希仁《计算机网络》第八版 |
| 操作系统 | 汤小丹《计算机操作系统》第四版 |
| 微观经济学 | 高鸿业《西方经济学（微观部分）》第八版 |
| 宏观经济学 | 高鸿业《西方经济学（宏观部分）》第八版 |
| 理论力学 | 哈尔滨工业大学理论力学教研室《理论力学》第八版 |
| 材料力学 | 刘鸿文《材料力学》第六版 |

When the exact edition cannot be definitively determined, use the most recent mainstream edition and note: "Based on the most recent mainstream edition; if your course uses a different edition, please specify."

---

## Priority 3: General Subject Knowledge Structure (Fallback)

When neither a user-specified textbook nor an auto-matched mainstream textbook can be determined:

1. Use general subject knowledge structure for knowledge point classification
2. Clearly mark all anchoring as **provisional** in Module 10 (Analysis Notes)
3. Add a recommendation: "教材锚定为临时性锚定，建议提供具体教材（作者+书名+版次）以获得精确章节级对齐"
4. Still maintain the 章 → 节 → 具体知识点 format where possible
5. Use standard subject terminology for knowledge point naming

---

## Three-Level Knowledge Point Classification

### Anchoring Format: 章 → 节 → 具体知识点

All anchoring follows the format: **章 (Chapter) → 节 (Section) → 具体知识点 (Specific Knowledge Point)**

### Level 1: Major Knowledge Modules (知识模块)
Broad categories corresponding to major sections or domains of the textbook.

**K-12 Examples:**
- **初中数学**: 数与式、方程与不等式、函数、图形的性质、图形的变化、统计与概率
- **高中物理**: 力学、电磁学、热学、光学、原子物理
- **高中语文**: 现代文阅读、古诗文阅读、语言文字运用、写作

**Higher Education Examples:**
- **电路 (Circuit Theory)**: 电路元件 (Circuit Elements), 直流电路 (DC Circuits), 交流电路 (AC Circuits), 暂态分析 (Transient Analysis), 频率响应 (Frequency Response), 二端口网络 (Two-Port Networks)
- **高等数学 (Advanced Mathematics)**: 极限 (Limits), 导数 (Derivatives), 积分 (Integrals), 级数 (Series), 微分方程 (Differential Equations), 多元微积分 (Multivariable Calculus)

### Level 2: Chapter / Section (章 / 节)
Corresponding to textbook chapters and sections.

**K-12 Example:**
- 初中数学 → 函数 → 第十九章 一次函数 → 19.2 一次函数

**Higher Education Example:**
- 电路 → 交流电路 → 第八章 相量法 → 8.3 相量法基础

### Level 3: Specific Knowledge Points (具体知识点)
Specific knowledge points or skills assessed in individual questions.

**K-12 Example:**
- 初中数学 → 函数 → 第十九章 一次函数 → 19.2 一次函数 → 一次函数的图像与性质（k值与图象位置关系）

**Higher Education Example:**
- 电路 → 交流电路 → 第八章 相量法 → 8.3 相量法基础 → 正弦量的相量表示及相量图绘制

---

## Textbook Anchoring Output Format

### Unified Anchoring Format
```
教材版本：[出版社]《[教材名称]》[第X版/册次]
章：[章编号与名称]
节：[节编号与名称]
具体考点：[考点内容]
```

### K-12 Example
```
教材版本：人教版《数学》八年级下册
章：第十九章 一次函数
节：19.2 一次函数 → 19.2.2 一次函数的图像与性质
具体考点：一次函数图像中k值与图象经过象限的关系
```

### Higher Education Example (User-Specified)
```
教材版本：邱关源《电路》第六版
章：第八章 相量法
节：8.3 相量法基础
具体考点：正弦量的相量表示及相量图绘制
```

### Higher Education Example (Auto-Matched)
```
教材版本：同济大学数学系《高等数学》第七版（自动匹配）
章：第三章 微分中值定理与导数的应用
节：3.1 微分中值定理
具体考点：拉格朗日中值定理的条件与结论
```

---

## Knowledge Point Coverage Estimation

### Method
1. Identify the full table of contents of the determined textbook
2. List all Level 1 and Level 2 knowledge points in the textbook's scope
3. Count how many are covered by the exam paper
4. Calculate coverage percentage

### Coverage Categories
- **High coverage**: 80%+ of the target textbook scope covered
- **Medium coverage**: 50-80% covered
- **Low coverage**: Below 50% covered

### Uncovered Core Knowledge
Identify important chapters or sections that are NOT covered by the exam paper, which is important for understanding the paper's limitations and scope.

---

## Exam Type Prediction

### K-12 Exam Types
1. **单元检测 (Unit Quiz)**: Focuses on recent unit/chapter content, narrow scope
2. **期中考试 (Midterm Exam)**: Covers first half of semester, moderate scope
3. **期末考试 (Final Exam)**: Covers full semester, comprehensive scope
4. **月考 (Monthly Exam)**: Covers recent month's learning, medium scope
5. **学业水平考试 (Academic Proficiency Exam)**: Covers full subject, standardized difficulty, pass/fail orientation
6. **中考模拟 (Senior High Entrance Exam Mock)**: Comprehensive Junior High scope, 中考-level difficulty
7. **高考模拟 (College Entrance Exam Mock)**: Comprehensive Senior High scope, 高考-level difficulty
8. **中考 (Senior High Entrance Exam)**: Provincial/municipal level, full Junior High scope, high-stakes
9. **高考 (College Entrance Exam)**: National/provincial level, full Senior High scope, high-stakes

### Higher Education Exam Types
1. **Quiz / Chapter Test**: Focuses on recent chapter content, narrow scope
2. **Midterm Exam**: Covers first half of course, moderate scope
3. **Final Exam**: Covers full course, comprehensive scope
4. **Make-up Exam**: Similar scope to original exam, may differ in difficulty
5. **Graduate Entrance Exam (考研)**: Comprehensive, high difficulty, competitive
6. **Certification Exam**: Professional certification, practical and comprehensive

### Prediction Factors
- Knowledge scope and coverage
- Difficulty level and distribution
- Question types and structure
- Overall length and estimated duration
- Score distribution patterns
- Whether the paper covers single unit, multiple units, or full subject scope

---

## Important Reminders
0. **No fabrication, no deviation**: This reference file is part of the exam-analysis skill framework. All chapter structures and knowledge point catalogs listed herein are authoritatively sourced. When a textbook is determined (user-specified or auto-matched), you MUST use the textbook's actual official table of contents for chapter/section anchoring. Never fabricate chapter numbers, section names, or knowledge point hierarchies from your own knowledge. The rule: what's in this reference and the textbook's actual TOC you may use; what's not there you must not invent. If the actual TOC is unavailable and not covered by this reference, fall back to general subject structure with provisional marking.
1. **Hybrid priority**: Always check for user-specified textbook first; only auto-match if none specified
2. **User-specified format**: Accept "Author + Title + Edition" (e.g., 邱关源《电路》第六版)
3. **Auto-match K-12**: 部编版 for 语文/历史/政治, 人教版 for others
4. **Auto-match Higher Ed**: Nationally recognized standard textbooks
5. **Fallback rule**: If no textbook can be determined, use general subject structure with provisional marking
6. **Anchoring format**: Always use 章 → 节 → 具体知识点 format
7. **Textbook consistency**: Use the same textbook edition across all analyses of the same exam set
8. **Naming consistency**: Use consistent knowledge point naming across all questions — match the textbook catalog
9. **Granularity control**: Ensure Level 3 exam points have similar level of specificity
10. **Evidence-based**: Subject identification must be supported by exam paper content
11. **State clearly**: Always state which textbook version is being used for anchoring in Module 10 (Analysis Notes)
12. **Note assumptions**: If exact textbook edition is uncertain, note the assumption and recommend user verification
