# Difficulty Assessment Standards
## Unified Criteria & Calculation Methods

This reference provides detailed difficulty assessment standards, scoring rate benchmarks, and calculation formulas for consistent application across all exam paper analyses.

---

## Unified Difficulty Classification Criteria

### Simple Questions
**Definition**: Questions that assess a single knowledge point with direct application of concepts or formulas.

**Characteristics**:
- Single knowledge point assessment
- Direct application of concepts, formulas, or definitions
- No traps or misleading elements
- Equivalent to basic textbook example difficulty
- Straightforward questioning method
- Can be solved in 1-2 steps with no transformation needed

**Examples**:
- Direct recall of definitions or formulas
- Simple calculation using a single formula
- Basic concept identification
- Direct application of textbook examples

**Estimated scoring rate**: 0.85 (85% of students answer correctly)

---

### Medium Questions
**Definition**: Questions that assess 2-3 related knowledge points, requiring 1-2 steps of reasoning or transformation.

**Characteristics**:
- 2-3 related knowledge points involved
- Require 1-2 steps of reasoning or transformation
- Contain common error-prone points
- May involve moderate concept discrimination
- Require basic knowledge integration
- Equivalent to medium-difficulty textbook exercises

**Examples**:
- Application of formula with conditional transformation
- Comparison and discrimination of similar concepts
- Multi-step calculation within a single knowledge module
- Simple comprehensive application within a chapter

**Estimated scoring rate**: 0.6 (60% of students answer correctly)

---

### Difficult Questions
**Definition**: Cross-module multi-knowledge-point integration questions requiring multi-step derivation, context transformation, or model construction.

**Characteristics**:
- Cross-module multi-knowledge-point integration
- Require multi-step derivation and reasoning
- Require context transformation or model construction
- Novel or creative questioning methods
- High degree of openness or exploration
- May involve complex scenario analysis
- Equivalent to final challenging (压轴) question difficulty

**Examples**:
- Comprehensive problems spanning multiple knowledge modules
- Open-ended inquiry questions
- Real-world context problems requiring model building
- Innovative question types with novel presentation
- Multi-layered reasoning chains
- Problems requiring flexible knowledge transfer

**Estimated scoring rate**: 0.3 (30% of students answer correctly)

---

## Difficulty Coefficient Calculation

### Formula
```
Estimated difficulty coefficient = (Simple score × 0.85 + Medium score × 0.6 + Difficult score × 0.3) ÷ Total score
```

### Scoring Rate Benchmarks
| Difficulty Level | Scoring Rate Benchmark |
|------------------|------------------------|
| Simple | 0.85 |
| Medium | 0.60 |
| Difficult | 0.30 |

### Interpretation of Difficulty Coefficient
| Difficulty Coefficient Range | Interpretation |
|------------------------------|----------------|
| 0.80 - 1.00 | Very easy paper, most students score well |
| 0.65 - 0.79 | Relatively easy paper, good for foundation assessment |
| 0.50 - 0.64 | Moderate difficulty, balanced assessment |
| 0.35 - 0.49 | Relatively difficult paper, good discrimination |
| Below 0.35 | Very difficult paper, high selection function |

---

## Difficulty Gradient Design Analysis

### Common Patterns
1. **Linear progression**: Difficulty increases gradually from beginning to end
2. **Wave pattern**: Difficulty fluctuates with easier questions interspersed
3. **Module-based**: Each question type has its own difficulty gradient
4. **Final challenge**: Difficulty spikes significantly at the end of each section or paper

### Assessment Points
- Is the overall difficulty arrangement reasonable?
- Where are the difficulty peaks located?
- Is there a reasonable gradient within each question type?
- Are the challenging questions appropriately positioned?
- Do different knowledge modules show different difficulty levels?

---

## Discrimination Power Assessment

### Definition
Discrimination power refers to the exam paper's ability to differentiate students of different proficiency levels.

### High Discrimination Indicators
- Reasonable difficulty distribution (not too easy or too hard)
- Appropriate proportion of medium-difficulty questions
- Good gradient from simple to difficult
- Comprehensive questions that can differentiate top students
- Basic questions that can identify students with weak foundations

### Low Discrimination Indicators
- Overall too easy: most students score high
- Overall too difficult: most students score low
- Too many extreme difficulty questions, lack of medium difficulty
- Questions with ambiguous or controversial answers

---

## Important Reminders
1. **Textbook-based**: Difficulty must be assessed relative to the corresponding textbook and course requirements, not personal subjective judgment
2. **Uniform standards**: Apply the same difficulty criteria consistently across all questions and all exam papers
3. **Evidence-based**: Difficulty classification must be justified by specific question characteristics
4. **No subjective adjustment**: Do not adjust difficulty based on perceived student ability; use objective criteria
5. **Context matters**: Consider the educational stage - what is "simple" in graduate school may be "difficult" in undergraduate
